package modelo;

public enum Company {

    //Lista de enums (campo de valores pré definidos)
    SonyComputerEntertainment, Activision, Nintendo, TakeTwoInteractive, MicrosoftGameStudios;
}
