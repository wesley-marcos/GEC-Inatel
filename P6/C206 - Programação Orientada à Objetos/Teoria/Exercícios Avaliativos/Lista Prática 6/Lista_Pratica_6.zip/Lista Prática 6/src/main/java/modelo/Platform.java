package modelo;

public enum Platform {

    //Lista de enums (campo de valores pré definidos)
    PS3, PS2, PS4, PC, XBOX, Wii, GB, XB360;
}
