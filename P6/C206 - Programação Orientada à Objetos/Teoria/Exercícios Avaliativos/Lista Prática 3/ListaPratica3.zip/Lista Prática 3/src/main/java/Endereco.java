public class Endereco{

    //Atributos
    public String rua;
    public String bairro;
    public int num;

    //Construtor
    public Endereco(String rua, String bairro, int num){
        this.rua = rua;
        this.bairro = bairro;
        this.num = num;
    }
}
