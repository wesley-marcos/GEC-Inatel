public class Hatch extends Carro{

    private int portas;

    //Getters e setters
    public int getPortas() {
        return portas;
    }

    public void setPortas(int portas) {
        this.portas = portas;
    }
}
