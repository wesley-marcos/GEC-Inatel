public class SUV extends Carro{

    private String tracao;

    //Getters e setters
    public String getTracao() {
        return tracao;
    }

    public void setTracao(String tracao) {
        this.tracao = tracao;
    }
}
