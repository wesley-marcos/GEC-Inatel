public interface Controle{

    public void mostraInfo();

}
