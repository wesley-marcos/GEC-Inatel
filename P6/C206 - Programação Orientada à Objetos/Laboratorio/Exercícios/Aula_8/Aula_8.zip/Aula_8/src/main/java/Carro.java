public abstract class Carro {

    protected double valor;
    protected String cor;
    protected int ano;
}
