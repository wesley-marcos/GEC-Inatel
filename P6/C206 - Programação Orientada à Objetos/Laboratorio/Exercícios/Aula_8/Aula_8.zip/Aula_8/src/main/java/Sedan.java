public class Sedan extends Carro{

    private int portaMalas;

    //Getters e setters
    public int getPortaMalas() {
        return portaMalas;
    }

    public void setPortaMalas(int portaMalas) {
        this.portaMalas = portaMalas;
    }
}
