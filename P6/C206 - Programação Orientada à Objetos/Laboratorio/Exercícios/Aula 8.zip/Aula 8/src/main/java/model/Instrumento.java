package model;

public class Instrumento {

    public String nome;
    public String marca;
    public int idade;

}


//DAO
//model