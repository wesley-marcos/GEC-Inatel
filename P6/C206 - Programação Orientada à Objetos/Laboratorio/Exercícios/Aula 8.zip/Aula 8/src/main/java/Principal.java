import dao.InstrumentoDAO;
import dao.LivroDAO;
import model.Instrumento;
import model.Livro;

public class Principal {

    public static void main(String[] args) {
        LivroDAO lDAO = new LivroDAO();

        Livro l1 = new Livro();
        l1.titulo = "Harry Potter e o Prisioneiro de Azkaban";
        l1.autor = "J. K. Rowling";
        l1.numPaginas = 317;
        
        //inserir--------------------------
        if(lDAO.inserirLivro(l1)){
            System.out.println("Livro Inserido!");
        }

        else{
            System.out.println("Alguma coisa deu errado!");
        }

        //alterar--------------------------
        l1.numPaginas = 318;
        if(lDAO.atualizarLivro(1, l1)){
            System.out.println("Livro alterado");
        }

        else{
            System.out.println("Alguma coisa n rolou");
        }

        //deletar---------------------------
        if(lDAO.deletarLivro(3)){
            System.out.println("Livro deletado");
        }
        else{
            System.out.println("Alguma coisa n rolou");
        }
    }
}
