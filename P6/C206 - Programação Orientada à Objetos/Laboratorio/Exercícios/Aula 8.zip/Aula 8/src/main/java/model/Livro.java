package model;

public class Livro {

    public String titulo;
    public String autor;
    public int numPaginas;
}
