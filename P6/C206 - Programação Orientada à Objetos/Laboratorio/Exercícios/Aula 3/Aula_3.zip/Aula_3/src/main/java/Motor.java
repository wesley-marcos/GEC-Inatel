public class Motor {

    int potencia;
    char tipo;

    @Override
    public String toString() {
        return "Motor{" +
                "Potencia = " + potencia + " CVV" +
                ", Tipo = '" + tipo + '\'' +
                '}';
    }
}
