public class Calculadora {

    //Atributos
    double num1;
    double num2;

    //Métodos

    //Método soma
    double somar(double num1, double num2){

        return num1 + num2;
    }

    //Método subtrair
    double subtrair(double num1, double num2){

        return num1 - num2;
    }

    //Método multiplicar
    double multiplicar(double num1, double num2){

        return num1 * num2;
    }

    //Método dividir
    double dividir(double num1, double num2){

        return num1 / num2;
    }
}
