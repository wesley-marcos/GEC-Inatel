import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        System.out.println("Hello World!");

        //VARIAVEIS PRIMITIVAS
        //INTEIROS
        byte num1 = 7;
        short num2 = 15;
        int num3 = 150;
        long num4 = 39987;

        num2 = num1;
        num1 = (byte) num2;

        //DECIMAIS
        float num5 = 3.14159f;
        double num6 = 27.89;

        //BOOLEANO
        boolean vdd = true;

        //Caracteres
        char letra = 't';

        System.out.println("Inteiro: " + num3);
        System.out.print("Float: " + num5);
        System.out.println("Boolean: " + vdd);
        System.out.println("Caracter: " + letra);

        //VARIAVEIS DE REFERENCIA
        String texto = "Meu primeiro textinho";
        System.out.println(texto);
        System.out.println(texto.charAt(7));
        System.out.println("Tamanho: " + texto.length());

        //CASTING OU COERÇÃO
        int umInteiro = 8;
        float umFloat = 3.7f;
        umFloat = umInteiro;
        System.out.println("Float: " + umFloat);

        umInteiro = (int) umFloat;
        System.out.println("Inteiro: " + umInteiro);

        Scanner sc = new Scanner(System.in);
        short idade = 21;
        /*
        System.out.println("Entre com seu nome: ");
        String nome = sc.nextLine();
        System.out.println("Nome: " + nome);

        System.out.println("Idade: ");
        idade = sc.nextShort();
        System.out.println("Idade: " + idade);

        sc.nextLine();
        System.out.println("Sobrenome");
        String sobrenome = sc.nextLine();
        System.out.println("Sobrenome: " + sobrenome);
        */

        if(idade>18){
            System.out.println("Tu já pode ser preso!");
        }
        else if(idade==18) {
            System.out.println("Acabou a vida boa, hora de pagar boleto");
        }
        else{
            System.out.println("Ainda ta na vida boa");
        }

        for (int i = 0; i < 10; i++) {
            System.out.println("i: " + i);
        }

        System.out.println("--------------------------------");
        int i=0;
        while(i < 15){
            System.out.println("I: " + i);
            i += 2;
        }

        System.out.println("------------------------------");
        do{
            System.out.println("ii: " + i);
            i-=4;
        }while(i>0);

        System.out.println("Entre com a opção: ");
        byte op = sc.nextByte();
        switch(op){
            case 0:
                System.out.println("Estamos no case 0");
                break;
            case 1:
                System.out.println("Estamos no case 1");
                break;
        }

    }
}
