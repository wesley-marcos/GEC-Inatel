public class Fruta {
    String nome;
    String cor;
}
